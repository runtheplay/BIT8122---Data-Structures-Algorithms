# Time Complexity: push O(1), pop O(1), peek O(1), bracket check O(n)
class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop() if self.items else None

    def peek(self):
        return self.items[-1] if self.items else None

    def is_empty(self):
        return len(self.items)==0


def balanced(expr):
    s = Stack()
    pairs = {')':'(', ']':'[', '}':'{'}
    for ch in expr:
        if ch in '([{':
            s.push(ch)
        elif ch in ')]}':
            if s.is_empty() or s.pop()!=pairs[ch]:
                return False
    return s.is_empty()

expr = '{[()()]}'
print('Expression:', expr)
print('Balanced:', balanced(expr))
