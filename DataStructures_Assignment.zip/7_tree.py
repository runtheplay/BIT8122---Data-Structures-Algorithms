# Time Complexity: Insert O(h), DFS O(n), BFS O(n)
from collections import deque

class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

class BinaryTree:
    def __init__(self):
        self.root = None

    def insert(self, data):
        if not self.root:
            self.root = Node(data)
            return
        q = deque([self.root])
        while q:
            temp = q.popleft()
            if not temp.left:
                temp.left = Node(data)
                return
            else:
                q.append(temp.left)
            if not temp.right:
                temp.right = Node(data)
                return
            else:
                q.append(temp.right)

    def bfs(self):
        q = deque([self.root])
        while q:
            node = q.popleft()
            print(node.data, end=' ')
            if node.left: q.append(node.left)
            if node.right: q.append(node.right)
        print()

    def dfs_preorder(self, node):
        if node:
            print(node.data, end=' ')
            self.dfs_preorder(node.left)
            self.dfs_preorder(node.right)

bt = BinaryTree()
for x in [1,2,3,4,5,6,7]:
    bt.insert(x)

print('BFS:')
bt.bfs()
print('DFS Preorder:')
bt.dfs_preorder(bt.root)
print()
