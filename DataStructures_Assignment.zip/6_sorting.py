# Time Complexity: Bubble Sort O(n^2), Insertion Sort O(n^2)

def bubble_sort(arr):
    a = arr[:]
    n = len(a)
    for i in range(n):
        for j in range(0, n-i-1):
            if a[j] > a[j+1]:
                a[j], a[j+1] = a[j+1], a[j]
        print(f'Pass {i+1}:', a)
    return a


def insertion_sort(arr):
    a = arr[:]
    for i in range(1, len(a)):
        key = a[i]
        j = i - 1
        while j >= 0 and a[j] > key:
            a[j+1] = a[j]
            j -= 1
        a[j+1] = key
    return a

arr = [64, 34, 25, 12, 22, 11, 90]
print('Bubble Sort Trace:')
print('Sorted:', bubble_sort(arr))
print('Insertion Sorted:', insertion_sort(arr))
