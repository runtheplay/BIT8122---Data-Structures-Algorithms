# Time Complexity: enqueue O(1), dequeue O(1), peek O(1)
class Queue:
    def __init__(self):
        self.items = []

    def enqueue(self, item):
        self.items.append(item)

    def dequeue(self):
        return self.items.pop(0) if self.items else None

    def peek(self):
        return self.items[0] if self.items else None

q = Queue()
q.enqueue(10)
print('After enqueue 10:', q.items)
q.enqueue(20)
print('After enqueue 20:', q.items)
q.enqueue(30)
print('After enqueue 30:', q.items)
print('Peek:', q.peek())
q.dequeue()
print('After dequeue:', q.items)
