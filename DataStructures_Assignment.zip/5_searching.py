# Time Complexity: Linear Search O(n), Binary Search O(log n)
arr = list(range(1, 41, 2))
target = 25


def linear_search(a, t):
    comp = 0
    for i, v in enumerate(a):
        comp += 1
        if v == t:
            return i, comp
    return -1, comp


def binary_search(a, t):
    low, high = 0, len(a)-1
    comp = 0
    while low <= high:
        mid = (low + high)//2
        comp += 1
        if a[mid] == t:
            return mid, comp
        elif a[mid] < t:
            low = mid + 1
        else:
            high = mid - 1
    return -1, comp

print('Array:', arr)
print('Target:', target)
print('Linear Search:', linear_search(arr, target))
print('Binary Search:', binary_search(arr, target))
